<script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
<link href="<?=base_url('assets/pages/css/profile.min.css');?>" rel="stylesheet" type="text/css" />
<script src="<?=base_url('assets/global/plugins/jquery-validation/js/jquery.validate.min.js');?>" type="text/javascript"></script>
<div class="portlet mt-element-ribbon light portlet-fit bordered">
	<div class="ribbon ribbon-vertical-right ribbon-shadow ribbon-color-primary uppercase">
		<div class="ribbon-sub ribbon-bookmark"></div>
		<i class="fa fa-star"></i>
	</div>
	<div class="portlet-body" style="text-align: justify;">
	<br>
	<br>
	Deskripsi aplikasi
	</div>
	<div class="portlet-title">
		<div class="caption">
			<i class=" icon-layers font-green"></i>
			<span class="caption-subject font-green bold uppercase">PROFIL PENULIS</span>
		</div>
	</div>
	<div style="text-align: center;">
	<!-- <img src='<?= base_url(); ?>assets/foto_profil.JPG' width='200px'/> -->
	</div>
	<div class="portlet-body" style="text-align: justify;">
	Data Pak Ayat
	</div>
	<!-- <div class="portlet light ">
		<div>
			<h4 class="profile-desc-title">Kontak Kami</h4>
			<span class="profile-desc-text"> Jln. Moh. Kahfi 1 No. 88C Jagakarsa, Jakarta Selatan - Indonesia. </span>
			<div class="margin-top-20 profile-desc-link">
				<i class="fa fa-phone"></i>
				<a href="#">+6221 788903387</a>
			</div>
			<div class="margin-top-20 profile-desc-link">
				<i class="fa fa-envelope"></i>
				<a href="#">info@indoguard.co.id</a>
			</div>
			<div class="margin-top-20 profile-desc-link">
				<i class="fa fa-globe"></i>
				<a href="#">https://indoguard.co.id/</a>
			</div>
			<div class="margin-top-20 profile-desc-link">
				<i class="fa fa-twitter"></i>
				<a href="#">@ICKcorp</a>
			</div>
			<div class="margin-top-20 profile-desc-link">
				<i class="fa fa-facebook"></i>
				<a href="#">Indoguardika Cipta Kreasi</a>
			</div>
		</div>
	</div> -->
</div>